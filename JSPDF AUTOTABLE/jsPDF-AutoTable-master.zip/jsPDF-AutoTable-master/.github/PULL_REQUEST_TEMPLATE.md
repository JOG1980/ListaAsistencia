Thanks for contributing! Make sure you don't include `dist` files or `package-lock.json` in your pull request. They often introduce unnecessary conflicts.
